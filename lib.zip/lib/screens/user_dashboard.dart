import 'package:flutter/material.dart';
import '../app_state.dart';
import '../services/auth_service.dart';

class UserDashboard extends StatefulWidget {
  const UserDashboard({super.key});
  @override
  State<UserDashboard> createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> with SingleTickerProviderStateMixin {
  late TabController _tab;
  List<Map<String, dynamic>> _donations = [];
  List<Map<String, dynamic>> _requests  = [];
  bool _loading = true;

  static const _green  = Color(0xFF2EB15B);
  static const _purple = Color(0xFF7C3AED);

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _loadData();
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    final d = await AuthService.myDonations();
    final r = await AuthService.myRequests();
    if (mounted) setState(() { _donations = d; _requests = r; _loading = false; });
  }

  Future<void> _signOut() async {
    await AuthService.signOut();
    if (mounted) AppStateScope.of(context).logout();
  }

  @override
  Widget build(BuildContext context) {
    final app  = AppStateScope.of(context);
    final dark = app.isDark;
    final scaffoldBg  = dark ? const Color(0xFF121212) : const Color(0xFFF5F5F5);
    final cardBg      = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond  = dark ? Colors.white60 : const Color(0xFF888888);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // ── Header ──────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(children: [
            Container(
              width: 48, height: 48,
              decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(12)),
              child: const Icon(Icons.person, color: Colors.white, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(app.userName, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: textPrimary)),
              Text(app.userEmail, style: TextStyle(fontSize: 12, color: textSecond)),
            ])),
            // Sign out button
            GestureDetector(
              onTap: _signOut,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: dark ? Colors.red.shade900.withValues(alpha: 0.4) : Colors.red.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: dark ? Colors.red.shade700 : Colors.red.shade200),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.logout, size: 15, color: dark ? Colors.red.shade300 : Colors.red.shade600),
                  const SizedBox(width: 6),
                  Text('Sign Out', style: TextStyle(fontSize: 13, color: dark ? Colors.red.shade300 : Colors.red.shade600, fontWeight: FontWeight.w600)),
                ]),
              ),
            ),
          ]),
        ),

        // ── Stats row ────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(children: [
            _StatCard(label: 'My Donations', value: _donations.length.toString(), color: _purple, icon: Icons.medication, dark: dark),
            const SizedBox(width: 12),
            _StatCard(label: 'My Requests', value: _requests.length.toString(), color: _green, icon: Icons.back_hand_outlined, dark: dark),
          ]),
        ),

        // ── Tabs ─────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: TabBar(
            controller: _tab,
            labelColor: _green,
            unselectedLabelColor: textSecond,
            indicatorColor: _green,
            indicatorSize: TabBarIndicatorSize.tab,
            dividerColor: dark ? Colors.white12 : const Color(0xFFE0E0E0),
            labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
            tabs: const [Tab(text: 'My Donations'), Tab(text: 'My Requests')],
          ),
        ),

        // ── Tab content ──────────────────────────────────
        Expanded(
          child: _loading
            ? const Center(child: CircularProgressIndicator(color: _green))
            : TabBarView(controller: _tab, children: [
                // Donations tab
                _donations.isEmpty
                  ? _EmptyState(icon: Icons.medication_outlined, text: 'No donations yet', dark: dark)
                  : RefreshIndicator(
                      onRefresh: _loadData, color: _green,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _donations.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 12),
                        itemBuilder: (_, i) => _DonationTile(data: _donations[i], cardBg: cardBg, textPrimary: textPrimary, textSecond: textSecond),
                      ),
                    ),
                // Requests tab
                _requests.isEmpty
                  ? _EmptyState(icon: Icons.back_hand_outlined, text: 'No requests yet', dark: dark)
                  : RefreshIndicator(
                      onRefresh: _loadData, color: _green,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: _requests.length,
                        separatorBuilder: (_, _) => const SizedBox(height: 12),
                        itemBuilder: (_, i) => _RequestTile(data: _requests[i], cardBg: cardBg, textPrimary: textPrimary, textSecond: textSecond),
                      ),
                    ),
              ]),
        ),
      ])),
    );
  }
}

// ── Stat card ──────────────────────────────────────────────
class _StatCard extends StatelessWidget {
  final String label, value;
  final Color color;
  final IconData icon;
  final bool dark;
  const _StatCard({required this.label, required this.value, required this.color, required this.icon, required this.dark});

  @override
  Widget build(BuildContext context) {
    final bg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14),
          boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))]),
        child: Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 20)),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color)),
            Text(label, style: TextStyle(fontSize: 11, color: dark ? Colors.white54 : Colors.grey)),
          ]),
        ]),
      ),
    );
  }
}

// ── Donation tile ──────────────────────────────────────────
class _DonationTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final Color cardBg, textPrimary, textSecond;
  const _DonationTile({required this.data, required this.cardBg, required this.textPrimary, required this.textSecond});

  @override
  Widget build(BuildContext context) {
    final status = data['status'] ?? 'available';
    final statusColor = status == 'available' ? const Color(0xFF2EB15B) : Colors.grey;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Row(children: [
        Container(width: 44, height: 44,
          decoration: BoxDecoration(color: const Color(0xFF7C3AED).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.medication, color: Color(0xFF7C3AED), size: 22)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(data['medication_name'] ?? '', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: textPrimary)),
          const SizedBox(height: 3),
          Text('Qty: ${data['quantity']} • Exp: ${data['expiry_date'] ?? 'N/A'}', style: TextStyle(fontSize: 12, color: textSecond)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
          child: Text(status, style: TextStyle(fontSize: 11, color: statusColor, fontWeight: FontWeight.w600)),
        ),
      ]),
    );
  }
}

// ── Request tile ───────────────────────────────────────────
class _RequestTile extends StatelessWidget {
  final Map<String, dynamic> data;
  final Color cardBg, textPrimary, textSecond;
  const _RequestTile({required this.data, required this.cardBg, required this.textPrimary, required this.textSecond});

  @override
  Widget build(BuildContext context) {
    final status = data['status'] ?? 'open';
    final statusColor = status == 'open' ? const Color(0xFF2EB15B) : Colors.grey;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))]),
      child: Row(children: [
        Container(width: 44, height: 44,
          decoration: BoxDecoration(color: const Color(0xFF2EB15B).withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
          child: const Icon(Icons.back_hand_outlined, color: Color(0xFF2EB15B), size: 20)),
        const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(data['medication_name'] ?? '', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: textPrimary)),
          const SizedBox(height: 3),
          Text('Needs: ${data['quantity_needed']}', style: TextStyle(fontSize: 12, color: textSecond)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
          child: Text(status, style: TextStyle(fontSize: 11, color: statusColor, fontWeight: FontWeight.w600)),
        ),
      ]),
    );
  }
}

// ── Empty state ────────────────────────────────────────────
class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  final bool dark;
  const _EmptyState({required this.icon, required this.text, required this.dark});

  @override
  Widget build(BuildContext context) => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 56, color: dark ? Colors.white24 : Colors.grey.shade300),
      const SizedBox(height: 14),
      Text(text, style: TextStyle(fontSize: 15, color: dark ? Colors.white38 : Colors.grey.shade400)),
    ]),
  );
}
