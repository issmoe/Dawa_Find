import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../app_state.dart';
import '../services/auth_service.dart';
import '../widgets/pharmacy_logo.dart';

class PharmacyDashboard extends StatefulWidget {
  const PharmacyDashboard({super.key});
  @override
  State<PharmacyDashboard> createState() => _PharmacyDashboardState();
}

class _PharmacyDashboardState extends State<PharmacyDashboard> {
  List<Map<String, dynamic>> _stock = [];
  bool _loading = true;
  static const _green = Color(0xFF2EB15B);

  @override
  void initState() { super.initState(); _loadStock(); }

  Future<void> _loadStock() async {
    setState(() => _loading = true);
    final s = await AuthService.myPharmacyStock();
    if (mounted) setState(() { _stock = s; _loading = false; });
  }

  Future<void> _signOut() async {
    await AuthService.signOut();
    if (mounted) AppStateScope.of(context).logout();
  }

  @override
  Widget build(BuildContext context) {
    final app  = AppStateScope.of(context);
    final dark = app.isDark;
    final scaffoldBg  = dark ? const Color(0xFF121212) : const Color(0xFFF5F5F5);
    final cardBg      = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond  = dark ? Colors.white60 : const Color(0xFF888888);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // ── Header ──────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(children: [
            Container(width: 48, height: 48,
              decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(12)),
              child: const PharmacyLogo(size: 48, bgColor: Color(0xFF2EB15B))),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(app.userName, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: textPrimary)),
              Text(app.userEmail, style: TextStyle(fontSize: 12, color: textSecond)),
            ])),
            GestureDetector(
              onTap: _signOut,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(
                  color: dark ? Colors.red.shade900.withValues(alpha: 0.4) : Colors.red.shade50,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: dark ? Colors.red.shade700 : Colors.red.shade200),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.logout, size: 15, color: dark ? Colors.red.shade300 : Colors.red.shade600),
                  const SizedBox(width: 6),
                  Text('Sign Out', style: TextStyle(fontSize: 13, color: dark ? Colors.red.shade300 : Colors.red.shade600, fontWeight: FontWeight.w600)),
                ]),
              ),
            ),
          ]),
        ),

        // ── Stats ────────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
          child: Row(children: [
            _StatCard(label: 'Total Items', value: _stock.length.toString(), color: _green, icon: Icons.inventory_2_outlined, dark: dark),
            const SizedBox(width: 12),
            _StatCard(
              label: 'In Stock',
              value: _stock.where((s) => s['in_stock'] == true).length.toString(),
              color: const Color(0xFF7C3AED),
              icon: Icons.check_circle_outline,
              dark: dark,
            ),
          ]),
        ),

        // ── Section title + add button ────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 24, 20, 12),
          child: Row(children: [
            Text('Medication Stock', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: textPrimary)),
            const Spacer(),
            GestureDetector(
              onTap: () => _showAddStockSheet(context, dark, cardBg, textPrimary),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(10)),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.add, color: Colors.white, size: 16),
                  SizedBox(width: 6),
                  Text('Add', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                ]),
              ),
            ),
          ]),
        ),

        // ── Stock list ────────────────────────────────────
        Expanded(
          child: _loading
            ? const Center(child: CircularProgressIndicator(color: _green))
            : _stock.isEmpty
              ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.inventory_2_outlined, size: 56, color: dark ? Colors.white24 : Colors.grey.shade300),
                  const SizedBox(height: 14),
                  Text('No stock added yet', style: TextStyle(fontSize: 15, color: dark ? Colors.white38 : Colors.grey.shade400)),
                ]))
              : RefreshIndicator(
                  onRefresh: _loadStock, color: _green,
                  child: ListView.separated(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: _stock.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final item    = _stock[i];
                      final inStock = item['in_stock'] == true;
                      return Dismissible(
                        key: Key(item['id']?.toString() ?? i.toString()),
                        direction: DismissDirection.endToStart,
                        background: Container(
                          alignment: Alignment.centerRight,
                          padding: const EdgeInsets.only(right: 20),
                          decoration: BoxDecoration(color: Colors.red.shade400, borderRadius: BorderRadius.circular(14)),
                          child: const Icon(Icons.delete_outline, color: Colors.white, size: 22),
                        ),
                        onDismissed: (_) async {
                          final itemId = item['id'];
                          setState(() => _stock.removeAt(i));
                          try {
                            await Supabase.instance.client
                                .from('pharmacy_stock')
                                .delete()
                                .eq('id', itemId);
                          } catch (_) { _loadStock(); }
                        },
                        child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(14),
                          boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))]),
                        child: Row(children: [
                          Container(width: 42, height: 42,
                            decoration: BoxDecoration(color: _green.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(10)),
                            child: const Icon(Icons.medication, color: _green, size: 20)),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(item['medication_name'] ?? '', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: textPrimary)),
                            const SizedBox(height: 3),
                            Text('Qty: ${item['quantity']} • Exp: ${item['expiry_date'] ?? 'N/A'}', style: TextStyle(fontSize: 12, color: textSecond)),
                          ])),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: (inStock ? _green : Colors.grey).withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(20)),
                            child: Text(inStock ? 'In Stock' : 'Out', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: inStock ? _green : Colors.grey)),
                          ),
                        ]),
                      ));
                    },
                  ),
                ),
        ),
      ])),
    );
  }

  void _showAddStockSheet(BuildContext ctx, bool dark, Color cardBg, Color textPrimary) {
    final nameCtrl = TextEditingController();
    final genericCtrl = TextEditingController();
    final qtyCtrl = TextEditingController();
    final expCtrl = TextEditingController();

    showModalBottomSheet(
      context: ctx,
      isScrollControlled: true,
      backgroundColor: cardBg,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Add Medication', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: textPrimary)),
          const SizedBox(height: 16),
          _SheetField(ctrl: nameCtrl,    hint: 'Medication name',  dark: dark),
          const SizedBox(height: 12),
          _SheetField(ctrl: genericCtrl, hint: 'Generic name',     dark: dark),
          const SizedBox(height: 12),
          _SheetField(ctrl: qtyCtrl,     hint: 'Quantity',         dark: dark, type: TextInputType.number),
          const SizedBox(height: 12),
          _SheetField(ctrl: expCtrl,     hint: 'Expiry (YYYY-MM-DD)', dark: dark),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity,
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: _green, foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () async {
                if (nameCtrl.text.trim().isEmpty || qtyCtrl.text.trim().isEmpty) return;
                final qty = int.tryParse(qtyCtrl.text.trim());
                if (qty == null || qty <= 0) return;

                Navigator.pop(ctx);

                // Fetch pharmacy id for this user
                final user = Supabase.instance.client.auth.currentUser;
                if (user == null) return;
                try {
                  final pharmacy = await Supabase.instance.client
                      .from('pharmacies')
                      .select('id')
                      .eq('user_id', user.id)
                      .maybeSingle();
                  if (pharmacy == null) return;

                  await Supabase.instance.client.from('pharmacy_stock').insert({
                    'pharmacy_id':     pharmacy['id'],
                    'medication_name': nameCtrl.text.trim(),
                    'generic_name':    genericCtrl.text.trim(),
                    'quantity':        qty,
                    'expiry_date':     expCtrl.text.trim().isEmpty ? null : expCtrl.text.trim(),
                    'in_stock':        true,
                  });
                  _loadStock();
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                      content: Text('${nameCtrl.text.trim()} added to stock!'),
                      backgroundColor: _green,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ));
                  }
                } catch (e) {
                  if (ctx.mounted) {
                    ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                      content: Text('Failed to add: $e'),
                      backgroundColor: Colors.red.shade600,
                      behavior: SnackBarBehavior.floating,
                    ));
                  }
                }
              },
              child: const Text('Add to Stock', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
            ),
          ),
        ]),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final Color color;
  final IconData icon;
  final bool dark;
  const _StatCard({required this.label, required this.value, required this.color, required this.icon, required this.dark});

  @override
  Widget build(BuildContext context) {
    final bg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(14),
          boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))]),
        child: Row(children: [
          Container(width: 40, height: 40,
            decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: color, size: 20)),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: color)),
            Text(label, style: TextStyle(fontSize: 11, color: dark ? Colors.white54 : Colors.grey)),
          ]),
        ]),
      ),
    );
  }
}

class _SheetField extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  final bool dark;
  final TextInputType? type;
  const _SheetField({required this.ctrl, required this.hint, required this.dark, this.type});

  @override
  Widget build(BuildContext context) => TextField(
    controller: ctrl,
    keyboardType: type,
    style: TextStyle(color: dark ? Colors.white : const Color(0xFF1A1A1A), fontSize: 14),
    decoration: InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: dark ? Colors.white38 : Colors.grey.shade400, fontSize: 14),
      filled: true,
      fillColor: dark ? const Color(0xFF1E2E45) : const Color(0xFFF5F5F5),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
      border:        OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: dark ? const Color(0xFF2A3E5C) : Colors.grey.shade300)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: dark ? const Color(0xFF2A3E5C) : Colors.grey.shade300)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF2EB15B), width: 1.5)),
    ),
  );
}
