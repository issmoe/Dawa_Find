import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../app_state.dart';
import '../l10n/strings.dart';
import '../widgets/auth_widgets.dart';
import '../widgets/pharmacy_logo.dart';

class DonateScreen extends StatefulWidget {
  const DonateScreen({super.key});
  @override
  State<DonateScreen> createState() => _DonateScreenState();
}

class _DonateScreenState extends State<DonateScreen> with SingleTickerProviderStateMixin {
  late TabController _tab;
  List<Map<String, dynamic>> _donations = [];
  bool _loading = true;
  static const _purple = Color(0xFF7C3AED);
  final _sb = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _fetchDonations();
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  void _showDonateSheet(BuildContext context, dynamic app, bool dark, Color textPrimary) {
    final nameCtrl    = TextEditingController();
    final genericCtrl = TextEditingController();
    final qtyCtrl     = TextEditingController();
    final expCtrl     = TextEditingController();
    final notesCtrl   = TextEditingController();
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final inputBg = dark ? const Color(0xFF252540) : const Color(0xFFF5F5F5);
    final inputBorder = dark ? const Color(0xFF3A3A55) : Colors.grey.shade300;
    final hintCol = dark ? Colors.white38 : Colors.grey.shade400;
    bool submitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: cardBg,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setSheetState) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('Donate a Medication', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: textPrimary)),
              const Spacer(),
              GestureDetector(onTap: () => Navigator.pop(ctx), child: Icon(Icons.close, color: dark ? Colors.white54 : Colors.grey.shade500)),
            ]),
            const SizedBox(height: 4),
            Text('Help others by donating unused medications', style: TextStyle(fontSize: 12, color: dark ? Colors.white54 : Colors.grey.shade500)),
            const SizedBox(height: 16),
            _SheetInput(ctrl: nameCtrl,    hint: 'Medication name *',    dark: dark, inputBg: inputBg, border: inputBorder, hintCol: hintCol),
            const SizedBox(height: 10),
            _SheetInput(ctrl: genericCtrl, hint: 'Generic name',         dark: dark, inputBg: inputBg, border: inputBorder, hintCol: hintCol),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _SheetInput(ctrl: qtyCtrl, hint: 'Quantity *', dark: dark, inputBg: inputBg, border: inputBorder, hintCol: hintCol, type: TextInputType.number)),
              const SizedBox(width: 10),
              Expanded(child: _SheetInput(ctrl: expCtrl, hint: 'Expiry (YYYY-MM)', dark: dark, inputBg: inputBg, border: inputBorder, hintCol: hintCol)),
            ]),
            const SizedBox(height: 10),
            _SheetInput(ctrl: notesCtrl, hint: 'Notes (optional)', dark: dark, inputBg: inputBg, border: inputBorder, hintCol: hintCol, maxLines: 2),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: _purple,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: submitting ? null : () async {
                  if (nameCtrl.text.trim().isEmpty || qtyCtrl.text.trim().isEmpty) return;
                  final qty = int.tryParse(qtyCtrl.text.trim());
                  if (qty == null || qty <= 0) return;
                  setSheetState(() => submitting = true);
                  try {
                    final user = _sb.auth.currentUser;
                    await _sb.from('donations').insert({
                      'donor_id':        user?.id,
                      'medication_name': nameCtrl.text.trim(),
                      'generic_name':    genericCtrl.text.trim(),
                      'quantity':        qty,
                      'expiry_date':     expCtrl.text.trim().isEmpty ? null : '${expCtrl.text.trim()}-01',
                      'notes':           notesCtrl.text.trim().isEmpty ? null : notesCtrl.text.trim(),
                      'status':          'available',
                    });
                    if (ctx.mounted) Navigator.pop(ctx);
                    _fetchDonations();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                        content: const Text('Donation submitted! Thank you 💚'),
                        backgroundColor: _purple,
                        behavior: SnackBarBehavior.floating,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ));
                    }
                  } catch (e) {
                    setSheetState(() => submitting = false);
                    if (ctx.mounted) {
                      ScaffoldMessenger.of(ctx).showSnackBar(SnackBar(
                        content: Text('Error: $e'),
                        backgroundColor: Colors.red.shade600,
                        behavior: SnackBarBehavior.floating,
                      ));
                    }
                  }
                },
                child: submitting
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('Submit Donation', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
              ),
            ),
          ]),
        ),
      ),
    );
  }

  Future<void> _fetchDonations() async {    setState(() => _loading = true);
    try {
      final res = await _sb
          .from('donations')
          .select('*, pharmacies(name, address, city)')
          .eq('status', 'available')
          .order('created_at', ascending: false);
      if (mounted) setState(() { _donations = List<Map<String, dynamic>>.from(res); _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final app  = AppStateScope.of(context);
    final s    = AppStrings.of(app.lang);
    final dark = app.isDark;
    final scaffoldBg  = dark ? const Color(0xFF121212) : const Color(0xFFF5F5F5);
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond  = dark ? Colors.white60 : const Color(0xFF888888);

    return Scaffold(
      backgroundColor: scaffoldBg,
      floatingActionButton: app.isLoggedIn
          ? FloatingActionButton.extended(
              onPressed: () => _showDonateSheet(context, app, dark, textPrimary),
              backgroundColor: _purple,
              icon: const Icon(Icons.add, color: Colors.white),
              label: const Text('Donate', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            )
          : null,
      body: SafeArea(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.donateTitle, style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: textPrimary)),
            const SizedBox(height: 4),
            Text(s.donateSubtitle, style: TextStyle(fontSize: 13, color: textSecond)),
            const SizedBox(height: 16),
            TabBar(
              controller: _tab,
              labelColor: _purple,
              unselectedLabelColor: textSecond,
              indicatorColor: _purple,
              indicatorSize: TabBarIndicatorSize.tab,
              dividerColor: dark ? Colors.white12 : const Color(0xFFE0E0E0),
              labelStyle: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w400, fontSize: 14),
              tabs: [Tab(text: s.browse), Tab(text: s.myDonations)],
            ),
          ]),
        ),
        Expanded(
          child: TabBarView(controller: _tab, children: [
            // ── Browse tab ──────────────────────────────
            _loading
              ? const Center(child: CircularProgressIndicator(color: _purple))
              : _donations.isEmpty
                ? Center(child: Text('No donations available', style: TextStyle(color: textSecond)))
                : RefreshIndicator(
                    onRefresh: _fetchDonations,
                    color: _purple,
                    child: ListView.separated(
                      padding: const EdgeInsets.all(16),
                      itemCount: _donations.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 12),
                      itemBuilder: (_, i) => _DonationCard(data: _donations[i], dark: dark),
                    ),
                  ),
            // ── My Donations tab ────────────────────────
            app.isLoggedIn
              ? _MyDonationsTab(dark: dark)
              : SignInRequired(dark: dark, s: s),
          ]),
        ),
      ])),
    );
  }
}

// ── My Donations (logged in users) ────────────────────────
class _MyDonationsTab extends StatefulWidget {
  final bool dark;
  const _MyDonationsTab({required this.dark});
  @override
  State<_MyDonationsTab> createState() => _MyDonationsTabState();
}

class _MyDonationsTabState extends State<_MyDonationsTab> {
  List<Map<String, dynamic>> _items = [];
  bool _loading = true;
  final _sb = Supabase.instance.client;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    final user = _sb.auth.currentUser;
    if (user == null) { setState(() => _loading = false); return; }
    try {
      final res = await _sb.from('donations').select('*, pharmacies(name)')
          .eq('donor_id', user.id).order('created_at', ascending: false);
      if (mounted) setState(() { _items = List<Map<String, dynamic>>.from(res); _loading = false; });
    } catch (_) { if (mounted) setState(() => _loading = false); }
  }

  @override
  Widget build(BuildContext context) {
    final dark = widget.dark;
    final textSecond = dark ? Colors.white60 : const Color(0xFF888888);
    if (_loading) return const Center(child: CircularProgressIndicator(color: Color(0xFF7C3AED)));
    if (_items.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.medication_outlined, size: 56, color: dark ? Colors.white24 : Colors.grey.shade300),
      const SizedBox(height: 14),
      Text('No donations yet', style: TextStyle(color: textSecond, fontSize: 15)),
    ]));
    }
    return RefreshIndicator(
      onRefresh: _load, color: const Color(0xFF7C3AED),
      child: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: _items.length,
        separatorBuilder: (_, _) => const SizedBox(height: 12),
        itemBuilder: (_, i) => _DonationCard(data: _items[i], dark: dark),
      ),
    );
  }
}

// ── Donation card ──────────────────────────────────────────
class _DonationCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final bool dark;
  static const _purple = Color(0xFF7C3AED);
  const _DonationCard({required this.data, required this.dark});

  @override
  Widget build(BuildContext context) {
    final cardBg  = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final divider = dark ? Colors.white12 : Colors.grey.shade100;
    final txtMain = dark ? Colors.white : const Color(0xFF1A1A1A);
    final txtSub  = dark ? Colors.white60 : const Color(0xFF888888);
    final txtDet  = dark ? Colors.white70 : const Color(0xFF555555);

    final pharmacy = data['pharmacies'] as Map<String, dynamic>?;
    final pharmName    = pharmacy?['name']    ?? '';
    final pharmAddress = pharmacy?['address'] ?? '';

    // Format expiry
    final expRaw = data['expiry_date'] as String?;
    final expLabel = expRaw != null ? 'Exp ${expRaw.substring(0, 7)}' : '';

    // Quantity label
    final qty = data['quantity'];
    final qtyLabel = qty != null ? '$qty tablet${qty == 1 ? '' : 's'}' : '';

    return Container(
      decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(14),
        boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 10, offset: const Offset(0, 3))]),
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            Container(width: 44, height: 44,
              decoration: BoxDecoration(color: _purple.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
              child: const Icon(Icons.medication, color: _purple, size: 22)),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(data['medication_name'] ?? '', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: txtMain)),
              const SizedBox(height: 2),
              Text(data['generic_name'] ?? '', style: TextStyle(fontSize: 12, color: txtSub)),
            ])),
            if (qtyLabel.isNotEmpty)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(color: _purple.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(20)),
                child: Text(qtyLabel, style: const TextStyle(fontSize: 12, color: _purple, fontWeight: FontWeight.w600)),
              ),
          ]),
        ),
        Divider(height: 1, color: divider),
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
          child: Column(children: [
            if (expLabel.isNotEmpty)    _Row(icon: Icons.calendar_month_outlined, text: expLabel,    color: txtDet),
            if (pharmName.isNotEmpty) ...[const SizedBox(height: 7), _PharmacyRow(name: pharmName, color: txtDet)],
            if (pharmAddress.isNotEmpty) ...[const SizedBox(height: 7), _Row(icon: Icons.location_on_outlined, text: pharmAddress, color: txtDet)],
            if (data['notes'] != null) ...[const SizedBox(height: 7), _Row(icon: Icons.info_outline, text: data['notes'],          color: txtDet)],
          ]),
        ),
      ]),
    );
  }
}

class _Row extends StatelessWidget {
  final IconData icon; final String text; final Color color;
  const _Row({required this.icon, required this.text, required this.color});
  @override
  Widget build(BuildContext context) => Row(children: [
    Icon(icon, size: 14, color: color.withValues(alpha: 0.7)),
    const SizedBox(width: 8),
    Expanded(child: Text(text, style: TextStyle(fontSize: 13, color: color))),
  ]);
}

class _PharmacyRow extends StatelessWidget {
  final String name;
  final Color color;
  const _PharmacyRow({required this.name, required this.color});
  @override
  Widget build(BuildContext context) => Row(children: [
    PharmacyLogo(size: 16, bgColor: color.withValues(alpha: 0.7), borderRadius: 3),
    const SizedBox(width: 8),
    Expanded(child: Text(name, style: TextStyle(fontSize: 13, color: color))),
  ]);
}

class _SheetInput extends StatelessWidget {
  final TextEditingController ctrl;
  final String hint;
  final bool dark;
  final Color inputBg, border, hintCol;
  final TextInputType? type;
  final int maxLines;
  const _SheetInput({required this.ctrl, required this.hint, required this.dark,
    required this.inputBg, required this.border, required this.hintCol,
    this.type, this.maxLines = 1});

  @override
  Widget build(BuildContext context) => TextField(
    controller: ctrl,
    keyboardType: type,
    maxLines: maxLines,
    style: TextStyle(color: dark ? Colors.white : const Color(0xFF1A1A1A), fontSize: 14),
    decoration: InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: hintCol, fontSize: 13),
      filled: true, fillColor: inputBg,
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      border:        OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide(color: border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: Color(0xFF7C3AED), width: 1.5)),
    ),
  );
}
