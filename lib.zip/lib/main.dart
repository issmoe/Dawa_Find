import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'app_state.dart';
import 'l10n/strings.dart';
import 'screens/find_screen.dart';
import 'screens/donate_screen.dart';
import 'screens/requests_screen.dart';
import 'screens/pharmacies_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(
    url: 'https://qyrnbnnhoysnfclxeexc.supabase.co',
    anonKey: 'sb_publishable_jH4TnMLOtI_yAKYOfgAd3Q_lpPLT1EQ',
  );
  runApp(const MedApp());
}

// Restore session on cold start
Future<void> _restoreSession(AppState appState) async {
  final sb   = Supabase.instance.client;
  final user = sb.auth.currentUser;
  if (user == null) return;
  final role = user.userMetadata?['role'] ?? 'user';
  if (role == 'pharmacy') {
    final row = await sb.from('pharmacies')
        .select('name').eq('user_id', user.id).maybeSingle();
    appState.login(
      type: UserType.pharmacy,
      name: row?['name'] ?? user.email?.split('@')[0] ?? '',
      email: user.email ?? '',
    );
  } else {
    appState.login(
      type: UserType.user,
      name: user.userMetadata?['full_name'] ?? user.email?.split('@')[0] ?? '',
      email: user.email ?? '',
    );
  }
}

class MedApp extends StatefulWidget {
  const MedApp({super.key});
  @override
  State<MedApp> createState() => _MedAppState();
}

class _MedAppState extends State<MedApp> {
  final _appState = AppState();

  @override
  void initState() {
    super.initState();
    _restoreSession(_appState);
  }

  @override
  void dispose() { _appState.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AppStateScope(
      state: _appState,
      child: ListenableBuilder(
        listenable: _appState,
        builder: (_, _) => MaterialApp(
          title: 'MedFinder',
          debugShowCheckedModeBanner: false,
          themeMode: _appState.isDark ? ThemeMode.dark : ThemeMode.light,
          theme:     _buildTheme(Brightness.light),
          darkTheme: _buildTheme(Brightness.dark),
          home: const MainShell(),
        ),
      ),
    );
  }

  ThemeData _buildTheme(Brightness b) => ThemeData(
    brightness: b,
    scaffoldBackgroundColor: b == Brightness.light ? const Color(0xFFF5F5F5) : const Color(0xFF121212),
    fontFamily: 'Roboto',
    useMaterial3: true,
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _index = 0;

  static const _screens = [
    FindScreen(), DonateScreen(), RequestsScreen(), PharmaciesScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    final app      = AppStateScope.of(context);
    final s        = AppStrings.of(app.lang);
    final navDark  = app.isDark;
    final navBg    = navDark ? const Color(0xFF162032) : Colors.white;
    final inactive = navDark ? Colors.white38 : Colors.grey;

    // 4th tab changes based on login state
    final accountIcon       = app.isLoggedIn ? Icons.account_circle          : Icons.account_circle_outlined;
    final accountIconActive = app.isLoggedIn ? Icons.account_circle          : Icons.account_circle_outlined;

    final items = [
      _NavDef(Icons.search,            Icons.search,        s.navFind),
      _NavDef(Icons.favorite_border,   Icons.favorite,      s.navDonate),
      _NavDef(Icons.back_hand_outlined, Icons.back_hand,    s.navRequests),
      _NavDef(accountIcon,             accountIconActive,   'Account'),
    ];

    return Directionality(
      textDirection: app.lang == 'AR' ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        body: IndexedStack(index: _index, children: _screens),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: navBg,
            boxShadow: [BoxShadow(color: Colors.black.withValues(alpha: navDark ? 0.4 : 0.08), blurRadius: 16, offset: const Offset(0, -4))],
          ),
          child: SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 8),
              child: Row(children: List.generate(items.length, (i) {
                final item   = items[i];
                final active = i == _index;
                final color  = active ? const Color(0xFF2EB15B) : inactive;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _index = i),
                    behavior: HitTestBehavior.opaque,
                    child: Column(mainAxisSize: MainAxisSize.min, children: [
                      Icon(active ? item.activeIcon : item.icon, size: 22, color: color),
                      const SizedBox(height: 4),
                      Text(item.label, style: TextStyle(fontSize: 11, color: color, fontWeight: active ? FontWeight.w700 : FontWeight.w400)),
                    ]),
                  ),
                );
              })),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavDef {
  final IconData icon, activeIcon;
  final String label;
  const _NavDef(this.icon, this.activeIcon, this.label);
}
