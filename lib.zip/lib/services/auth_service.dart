import 'package:supabase_flutter/supabase_flutter.dart';

final _sb = Supabase.instance.client;

class AuthService {
  static User? get currentUser => _sb.auth.currentUser;
  static bool get isLoggedIn => _sb.auth.currentUser != null;

  static Future<AuthResult> userSignUp({
    required String fullName,
    required String email,
    required String password,
    String? phone,
  }) async {
    try {
      final res = await _sb.auth.signUp(
        email: email, password: password,
        data: {'full_name': fullName, 'phone': phone ?? '', 'role': 'user'},
      );
      if (res.user == null) return AuthResult.error('Sign up failed.');
      return AuthResult.success(name: fullName, email: email, role: 'user');
    } on AuthException catch (e) { return AuthResult.error(e.message); }
    catch (e) { return AuthResult.error('Unexpected error. Please try again.'); }
  }

  static Future<AuthResult> userSignIn({
    required String email,
    required String password,
  }) async {
    try {
      final res = await _sb.auth.signInWithPassword(email: email, password: password);
      final name = res.user?.userMetadata?['full_name'] ?? email.split('@')[0];
      return AuthResult.success(name: name, email: email, role: 'user');
    } on AuthException catch (e) { return AuthResult.error(e.message); }
    catch (e) { return AuthResult.error('Unexpected error. Please try again.'); }
  }

  static Future<AuthResult> pharmacySignUp({
    required String pharmacyName,
    required String address,
    required String city,
    required String phone,
    required String email,
    required String password,
    String? openingHours,
    bool isDonationPoint = false,
    String? certificateUrl,
  }) async {
    try {
      final res = await _sb.auth.signUp(
        email: email, password: password,
        data: {'full_name': pharmacyName, 'role': 'pharmacy'},
      );
      if (res.user == null) return AuthResult.error('Sign up failed.');
      await _sb.from('pharmacies').insert({
        'user_id': res.user!.id, 'name': pharmacyName,
        'address': address, 'city': city, 'phone': phone,
        'opening_hours': openingHours,
        'is_donation_point': isDonationPoint,
        'certificate_url': certificateUrl,
      });
      return AuthResult.success(name: pharmacyName, email: email, role: 'pharmacy');
    } on AuthException catch (e) { return AuthResult.error(e.message); }
    on PostgrestException catch (e) { return AuthResult.error(e.message); }
    catch (e) { return AuthResult.error('Unexpected error. Please try again.'); }
  }

  static Future<AuthResult> pharmacySignIn({
    required String email,
    required String password,
  }) async {
    try {
      await _sb.auth.signInWithPassword(email: email, password: password);
      // fetch pharmacy name
      final user = _sb.auth.currentUser;
      String name = email.split('@')[0];
      if (user != null) {
        final row = await _sb.from('pharmacies')
            .select('name').eq('user_id', user.id).maybeSingle();
        if (row != null) name = row['name'] ?? name;
      }
      return AuthResult.success(name: name, email: email, role: 'pharmacy');
    } on AuthException catch (e) { return AuthResult.error(e.message); }
    catch (e) { return AuthResult.error('Unexpected error. Please try again.'); }
  }

  static Future<void> signOut() async => await _sb.auth.signOut();

  // Fetch current user's donations
  static Future<List<Map<String, dynamic>>> myDonations() async {
    final user = _sb.auth.currentUser;
    if (user == null) return [];
    final res = await _sb.from('donations')
        .select('*, pharmacies(name)')
        .eq('donor_id', user.id)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(res);
  }

  // Fetch current user's requests
  static Future<List<Map<String, dynamic>>> myRequests() async {
    final user = _sb.auth.currentUser;
    if (user == null) return [];
    final res = await _sb.from('donation_requests')
        .select()
        .eq('requester_id', user.id)
        .order('created_at', ascending: false);
    return List<Map<String, dynamic>>.from(res);
  }

  // Fetch pharmacy stock for logged-in pharmacy
  static Future<List<Map<String, dynamic>>> myPharmacyStock() async {
    final user = _sb.auth.currentUser;
    if (user == null) return [];
    final pharmacy = await _sb.from('pharmacies')
        .select('id').eq('user_id', user.id).maybeSingle();
    if (pharmacy == null) return [];
    final res = await _sb.from('pharmacy_stock')
        .select()
        .eq('pharmacy_id', pharmacy['id'])
        .order('medication_name');
    return List<Map<String, dynamic>>.from(res);
  }
}

class AuthResult {
  final bool success;
  final String? error;
  final String? name;
  final String? email;
  final String? role;
  const AuthResult._({required this.success, this.error, this.name, this.email, this.role});
  factory AuthResult.success({required String name, required String email, required String role}) =>
      AuthResult._(success: true, name: name, email: email, role: role);
  factory AuthResult.error(String msg) => AuthResult._(success: false, error: msg);
}
