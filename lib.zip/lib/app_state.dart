import 'package:flutter/material.dart';

enum UserType { none, user, pharmacy }

class AppState extends ChangeNotifier {
  bool _isDark = false;
  String _lang = 'EN';
  UserType _userType = UserType.none;
  String _userName = '';
  String _userEmail = '';

  bool get isDark    => _isDark;
  String get lang    => _lang;
  UserType get userType => _userType;
  bool get isLoggedIn  => _userType != UserType.none;
  bool get isUser      => _userType == UserType.user;
  bool get isPharmacy  => _userType == UserType.pharmacy;
  String get userName  => _userName;
  String get userEmail => _userEmail;

  void toggleTheme() { _isDark = !_isDark; notifyListeners(); }
  void setLang(String l) { _lang = l; notifyListeners(); }

  void login({ required UserType type, required String name, required String email }) {
    _userType  = type;
    _userName  = name;
    _userEmail = email;
    notifyListeners();
  }

  void logout() {
    _userType  = UserType.none;
    _userName  = '';
    _userEmail = '';
    notifyListeners();
  }
}

class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({ super.key, required AppState state, required super.child })
      : super(notifier: state);

  static AppState of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<AppStateScope>()!.notifier!;
}
