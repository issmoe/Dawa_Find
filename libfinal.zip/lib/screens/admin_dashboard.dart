import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../app_state.dart';
import '../services/auth_service.dart';
import '../widgets/pharmacy_logo.dart';

class AdminDashboard extends StatefulWidget {
  const AdminDashboard({super.key});

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> with SingleTickerProviderStateMixin {
  late TabController _tab;
  bool _loading = true;
  
  int _totalUsers = 0;
  int _totalPharmacies = 0;
  int _totalDonations = 0;
  int _totalRequests = 0;

  List<Map<String, dynamic>> _pharmacies = [];
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _medications = [];
  List<Map<String, dynamic>> _donations = [];
  List<Map<String, dynamic>> _requests = [];

  final _sb = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 6, vsync: this);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _loading = true);
    try {
      // Load Stats
      final pharmsRes = await _sb.from('pharmacies').select('id').count(CountOption.exact);
      final donsRes = await _sb.from('donations').select('id').count(CountOption.exact);
      final reqsRes = await _sb.from('donation_requests').select('id').count(CountOption.exact);
      
      _totalPharmacies = pharmsRes.count;
      _totalDonations = donsRes.count;
      _totalRequests = reqsRes.count;
      // We will skip users count if there's no public users table
      
      // Load Pharmacies
      final pList = await _sb.from('pharmacies').select('*').order('created_at', ascending: false);
      _pharmacies = List<Map<String, dynamic>>.from(pList);

      // Load Users
      try {
        final uList = await _sb.from('profiles').select('*').order('created_at', ascending: false);
        _users = List<Map<String, dynamic>>.from(uList);
        _totalUsers = _users.length;
      } catch (e) {
        debugPrint('Error loading profiles: $e');
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Failed to load user profiles: $e'),
            backgroundColor: Colors.red.shade600,
            behavior: SnackBarBehavior.floating,
          ));
        }
      }

      // Load Medications
      final mList = await _sb.from('medications').select('*').order('name');
      _medications = List<Map<String, dynamic>>.from(mList);

      // Load Donations (plain query — names resolved from _users list)
      final dList = await _sb.from('donations').select('*').order('created_at', ascending: false);
      _donations = List<Map<String, dynamic>>.from(dList);

      // Load Requests (plain query — names resolved from _users list)
      final rList = await _sb.from('donation_requests').select('*').order('created_at', ascending: false);
      _requests = List<Map<String, dynamic>>.from(rList);
      
    } catch (e) {
      debugPrint('Admin load error: $e');
    }
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _deleteDonation(String id) async {
    final dark = AppStateScope.of(context).isDark;
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond  = dark ? Colors.white70 : const Color(0xFF555555);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete Donation?', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('This will permanently remove this donation record.', style: TextStyle(color: textSecond)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel', style: TextStyle(color: textSecond))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await _sb.from('donations').delete().eq('id', id);
      _loadData();
    } catch (e) { debugPrint('Error deleting donation: $e'); }
  }

  Future<void> _deleteRequest(String id) async {
    final dark = AppStateScope.of(context).isDark;
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond  = dark ? Colors.white70 : const Color(0xFF555555);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete Request?', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('This will permanently remove this medication request.', style: TextStyle(color: textSecond)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel', style: TextStyle(color: textSecond))),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await _sb.from('donation_requests').delete().eq('id', id);
      _loadData();
    } catch (e) { debugPrint('Error deleting request: $e'); }
  }

  Future<void> _togglePharmacyApproval(String id, bool currentStatus) async {
    try {
      await _sb.from('pharmacies').update({'is_verified': !currentStatus}).eq('id', id);
      _loadData();
    } catch (e) {
      debugPrint('Error toggling approval: $e');
    }
  }

  Future<void> _toggleCollectionPoint(String id, bool currentStatus) async {
    try {
      await _sb.from('pharmacies').update({'is_donation_point': !currentStatus}).eq('id', id);
      _loadData();
    } catch (e) {
      debugPrint('Error toggling donation point: $e');
    }
  }

  Future<void> _deleteUser(String id) async {
    final dark = AppStateScope.of(context).isDark;
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond = dark ? Colors.white70 : const Color(0xFF555555);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete User Account?', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('This will permanently remove the user profile. The Auth account must be deleted via Supabase Dashboard.', style: TextStyle(color: textSecond)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel', style: TextStyle(color: textSecond))),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await _sb.from('profiles').delete().eq('id', id);
      _loadData();
    } catch (e) {
      debugPrint('Error deleting user: $e');
    }
  }

  Future<void> _deletePharmacy(String id) async {
    final dark = AppStateScope.of(context).isDark;
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond = dark ? Colors.white70 : const Color(0xFF555555);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete Pharmacy?', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('This will remove the pharmacy and its stock. The Auth account must be deleted via Supabase Dashboard.', style: TextStyle(color: textSecond)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel', style: TextStyle(color: textSecond))),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await _sb.from('pharmacies').delete().eq('id', id);
      _loadData();
    } catch (e) {
      debugPrint('Error deleting pharmacy: $e');
    }
  }

  Future<void> _deleteMedication(String id) async {
    final dark = AppStateScope.of(context).isDark;
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond = dark ? Colors.white70 : const Color(0xFF555555);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Delete Medication?', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('This action cannot be undone and will remove it from the dictionary.', style: TextStyle(color: textSecond)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text('Cancel', style: TextStyle(color: textSecond))),
          ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
            onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (confirm != true) return;
    try {
      await _sb.from('medications').delete().eq('id', id);
      AuthService.invalidateDrugCache();
      _loadData();
    } catch (e) {
      debugPrint('Error deleting medication: $e');
    }
  }

  void _showAddDrugSheet(Color cardBg, Color textPrimary, Color textSecond) {
    final nameCtrl = TextEditingController();
    final genericCtrl = TextEditingController();
    bool submitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: cardBg,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (sheetContext) => StatefulBuilder(
        builder: (innerContext, setSheetState) => Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(innerContext).viewInsets.bottom + 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Add Medication', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: textPrimary)),
              const SizedBox(height: 16),
              TextField(
                controller: nameCtrl,
                style: TextStyle(color: textPrimary),
                decoration: InputDecoration(
                  labelText: 'Brand Name *',
                  labelStyle: TextStyle(color: textSecond),
                  border: const OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: genericCtrl,
                style: TextStyle(color: textPrimary),
                decoration: InputDecoration(
                  labelText: 'Generic Name (optional)',
                  labelStyle: TextStyle(color: textSecond),
                  border: const OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blueAccent,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                  ),
                  onPressed: submitting ? null : () async {
                    if (nameCtrl.text.trim().isEmpty) return;
                    setSheetState(() => submitting = true);
                    try {
                      await _sb.from('medications').insert({
                        'name': nameCtrl.text.trim(),
                        'generic_name': genericCtrl.text.trim().isEmpty ? null : genericCtrl.text.trim(),
                      });
                      AuthService.invalidateDrugCache();
                      if (innerContext.mounted) Navigator.pop(innerContext);
                      _loadData();
                    } catch (e) {
                      setSheetState(() => submitting = false);
                      debugPrint('Error adding drug: $e');
                    }
                  },
                  child: submitting ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('Save Medication'),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  Future<void> _signOut() async {
    final app = AppStateScope.of(context);
    final dark = app.isDark;
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond = dark ? Colors.white70 : const Color(0xFF555555);

    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: cardBg,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('Sign Out', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
        content: Text('Are you sure you want to sign out from the Admin Dashboard?', style: TextStyle(color: textSecond)),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel', style: TextStyle(color: textSecond)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Sign Out'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await AuthService.signOut();
      if (mounted) AppStateScope.of(context).logout();
    }
  }

  @override
  Widget build(BuildContext context) {
    final app = AppStateScope.of(context);
    final dark = app.isDark;
    final textPrimary = dark ? Colors.white : const Color(0xFF1A1A1A);
    final textSecond = dark ? Colors.white60 : const Color(0xFF888888);
    final scaffoldBg = dark ? const Color(0xFF121212) : const Color(0xFFF5F5F5);

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Admin Dashboard', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: textPrimary)),
                      IconButton(
                        onPressed: _signOut,
                        icon: const Icon(Icons.logout, color: Colors.redAccent),
                        tooltip: 'Logout',
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  TabBar(
                    controller: _tab,
                    labelColor: Colors.blueAccent,
                    unselectedLabelColor: textSecond,
                    indicatorColor: Colors.blueAccent,
                    isScrollable: true,
                    tabAlignment: TabAlignment.start,
                    tabs: const [
                      Tab(text: 'Overview'),
                      Tab(text: 'Accounts'),
                      Tab(text: 'Verification'),
                      Tab(text: 'Donations'),
                      Tab(text: 'Requests'),
                      Tab(text: 'Dictionary'),
                    ],
                  ),
                ],
              ),
            ),
            Expanded(
              child: _loading 
                ? const Center(child: CircularProgressIndicator())
                : TabBarView(
                    controller: _tab,
                    children: [
                      _buildOverview(textPrimary, textSecond, dark),
                      _buildAllAccounts(textPrimary, textSecond, dark),
                      _buildPharmacies(textPrimary, textSecond, dark),
                      _buildDonations(textPrimary, textSecond, dark),
                      _buildRequests(textPrimary, textSecond, dark),
                      _buildDrugs(textPrimary, textSecond, dark),
                    ],
                  ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOverview(Color textPrimary, Color textSecond, bool dark) {
    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        _statCard('Total Pharmacies', _totalPharmacies.toString(), Icons.local_pharmacy, Colors.green, dark,
            customIcon: const PharmacyLogo(size: 28, bgColor: Color(0xFF2EB15B))),
        const SizedBox(height: 16),
        _statCard('Total Users', _totalUsers.toString(), Icons.people, Colors.blue, dark),
        const SizedBox(height: 16),
        _statCard('Total Donations', _totalDonations.toString(), Icons.favorite, Colors.purple, dark),
        const SizedBox(height: 16),
        _statCard('Total Requests', _totalRequests.toString(), Icons.back_hand, Colors.orange, dark),
      ],
    );
  }

  Widget _buildAllAccounts(Color textPrimary, Color textSecond, bool dark) {
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    if (_pharmacies.isEmpty && _users.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.people_outline, size: 56, color: dark ? Colors.white24 : Colors.grey.shade300),
        const SizedBox(height: 14),
        Text('No accounts found', style: TextStyle(color: textSecond, fontSize: 15)),
      ]));
    }
    return RefreshIndicator(
      onRefresh: _loadData,
      color: Colors.blueAccent,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          if (_pharmacies.isNotEmpty) ...[
            Text('Pharmacies (${_pharmacies.length})', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textPrimary)),
            const SizedBox(height: 8),
            ..._pharmacies.map((p) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: Colors.green.withValues(alpha: 0.1),
                  child: const PharmacyLogo(size: 36, bgColor: Color(0xFF2EB15B)),
                ),
                title: Text(p['name'] ?? '', style: TextStyle(color: textPrimary, fontWeight: FontWeight.w600)),
                subtitle: Text(p['city'] ?? '', style: TextStyle(color: textSecond)),
                trailing: IconButton(icon: const Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: () => _deletePharmacy(p['id'].toString())),
              ),
            )),
            const SizedBox(height: 24),
          ],
          if (_users.isNotEmpty) ...[
            Text('Regular Users (${_users.length})', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textPrimary)),
            const SizedBox(height: 8),
            ..._users.map((u) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              decoration: BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(12)),
              child: ListTile(
                leading: CircleAvatar(backgroundColor: Colors.blue.withValues(alpha: 0.1), child: const Icon(Icons.person, color: Colors.blue, size: 20)),
                title: Text(u['full_name'] ?? 'No Name', style: TextStyle(color: textPrimary, fontWeight: FontWeight.w600)),
                subtitle: Text(u['phone'] ?? 'No Phone', style: TextStyle(color: textSecond)),
                trailing: IconButton(icon: const Icon(Icons.delete_outline, color: Colors.redAccent), onPressed: () => _deleteUser(u['id'].toString())),
              ),
            )),
          ],
        ],
      ),
    );
  }

  Widget _statCard(String title, String value, IconData icon, Color color, bool dark, {Widget? customIcon}) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF1E1E2E) : Colors.white,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: color.withValues(alpha: 0.1), borderRadius: BorderRadius.circular(12)),
            child: customIcon ?? Icon(icon, color: color, size: 28),
          ),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: dark ? Colors.white : Colors.black)),
              Text(title, style: TextStyle(fontSize: 14, color: dark ? Colors.white60 : Colors.black54)),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildPharmacies(Color textPrimary, Color textSecond, bool dark) {
    final pending = _pharmacies.where((p) => p['is_verified'] != true).toList();
    final accepted = _pharmacies.where((p) => p['is_verified'] == true).toList();

    return RefreshIndicator(
      onRefresh: _loadData,
      color: Colors.blueAccent,
      child: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (pending.isNotEmpty) ...[
          Text('Pending Verification', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textPrimary)),
          const SizedBox(height: 8),
          ...pending.map((p) => _pharmacyCard(p, textPrimary, textSecond, dark)),
          const SizedBox(height: 24),
        ],
        if (accepted.isNotEmpty) ...[
          Text('Accepted Pharmacies', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: textPrimary)),
          const SizedBox(height: 8),
          ...accepted.map((p) => _pharmacyCard(p, textPrimary, textSecond, dark)),
        ],
        if (pending.isEmpty && accepted.isEmpty)
          Center(child: Padding(
            padding: const EdgeInsets.only(top: 40),
            child: Text('No pharmacies found.', style: TextStyle(color: textSecond)),
          )),
      ],
      ),
    );
  }

  Widget _pharmacyCard(Map<String, dynamic> p, Color textPrimary, Color textSecond, bool dark) {
    final isApproved = p['is_verified'] == true;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: dark ? const Color(0xFF1E1E2E) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4))],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(p['name'] ?? 'Unknown', style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold, fontSize: 16)),
                      const SizedBox(height: 4),
                      Text('${p['city'] ?? 'No city'} • ${p['phone'] ?? 'No phone'}', style: TextStyle(color: textSecond, fontSize: 13)),
                    ],
                  ),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Verified', style: TextStyle(color: textSecond, fontSize: 12)),
                        Switch(
                          value: isApproved,
                          onChanged: (val) => _togglePharmacyApproval(p['id'].toString(), !val),
                          activeThumbColor: Colors.green,
                        ),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text('Collection Point', style: TextStyle(color: textSecond, fontSize: 12)),
                        Switch(
                          value: p['is_donation_point'] == true,
                          onChanged: (val) => _toggleCollectionPoint(p['id'].toString(), !val),
                          activeThumbColor: Colors.blueAccent,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            if (p['certificate_url'] != null && p['certificate_url'].toString().isNotEmpty) ...[
              const Divider(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.verified_user_outlined, size: 16, color: Colors.blueAccent),
                      const SizedBox(width: 8),
                      Text('Proof Provided', style: TextStyle(color: Colors.blueAccent, fontSize: 13, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  TextButton.icon(
                    onPressed: () {
                      // Show proof in a dialog or link
                      showDialog(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text('Verification Proof'),
                          content: Image.network(p['certificate_url'].toString(), 
                            errorBuilder: (_, _, _) => const Text('Could not load image.')),
                          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
                        ),
                      );
                    },
                    icon: const Icon(Icons.visibility, size: 16),
                    label: const Text('View Proof'),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDrugs(Color textPrimary, Color textSecond, bool dark) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(16),
          child: ElevatedButton.icon(
            onPressed: () => _showAddDrugSheet(dark ? const Color(0xFF1E1E2E) : Colors.white, textPrimary, textSecond),
            icon: const Icon(Icons.add),
            label: const Text('Add Medication'),
            style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(54), padding: const EdgeInsets.all(16)),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: _medications.length,
            itemBuilder: (ctx, i) {
              final m = _medications[i];
              return Container(
                margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: dark ? const Color(0xFF1E1E2E) : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.04), blurRadius: 8, offset: const Offset(0, 2))],
                ),
                child: ListTile(
                  title: Text(m['name'], style: TextStyle(color: textPrimary, fontWeight: FontWeight.bold)),
                  subtitle: m['generic_name'] != null ? Text(m['generic_name'], style: TextStyle(color: textSecond)) : null,
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                    onPressed: () => _deleteMedication(m['id'].toString()),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildDonations(Color textPrimary, Color textSecond, bool dark) {
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    if (_donations.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.favorite_outline, size: 56, color: dark ? Colors.white24 : Colors.grey.shade300),
        const SizedBox(height: 14),
        Text('No donations yet', style: TextStyle(color: textSecond, fontSize: 15)),
      ]));
    }
    return RefreshIndicator(
      onRefresh: _loadData,
      color: Colors.blueAccent,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _donations.length,
        itemBuilder: (_, i) {
          final d = _donations[i];
          final donorId = d['donor_id']?.toString() ?? '';
          final donorProfile = _users.firstWhere(
            (u) => u['id']?.toString() == donorId,
            orElse: () => {},
          );
          final donorName = donorProfile['full_name'] as String?
              ?? (donorId.isNotEmpty ? 'ID: ${donorId.substring(0, 8)}…' : 'Unknown');
          final status = (d['status'] ?? 'pending').toString();
          final statusColor = status == 'accepted'
              ? Colors.green : status == 'rejected'
              ? Colors.redAccent : Colors.orange;
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(14),
              boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: CircleAvatar(
                backgroundColor: Colors.purple.withValues(alpha: 0.12),
                child: const Icon(Icons.favorite, color: Colors.purple, size: 20),
              ),
              title: Text(d['medication_name'] ?? 'Unknown medication',
                  style: TextStyle(color: textPrimary, fontWeight: FontWeight.w600)),
              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const SizedBox(height: 2),
                Text('By: $donorName', style: TextStyle(color: textSecond, fontSize: 12)),
                const SizedBox(height: 2),
                Row(children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
                    child: Text(status.toUpperCase(), style: TextStyle(fontSize: 11, color: statusColor, fontWeight: FontWeight.w700)),
                  ),
                  if ((d['quantity'] ?? '') != '') ...[ const SizedBox(width: 8),
                    Text('Qty: ${d['quantity']}', style: TextStyle(color: textSecond, fontSize: 12))],
                ]),
              ]),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () => _deleteDonation(d['id'].toString()),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildRequests(Color textPrimary, Color textSecond, bool dark) {
    final cardBg = dark ? const Color(0xFF1E1E2E) : Colors.white;
    if (_requests.isEmpty) {
      return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.back_hand_outlined, size: 56, color: dark ? Colors.white24 : Colors.grey.shade300),
        const SizedBox(height: 14),
        Text('No requests yet', style: TextStyle(color: textSecond, fontSize: 15)),
      ]));
    }
    return RefreshIndicator(
      onRefresh: _loadData,
      color: Colors.blueAccent,
      child: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _requests.length,
        itemBuilder: (_, i) {
          final r = _requests[i];
          final requesterId = r['requester_id']?.toString() ?? '';
          final requesterProfile = _users.firstWhere(
            (u) => u['id']?.toString() == requesterId,
            orElse: () => {},
          );
          final requesterName = requesterProfile['full_name'] as String?
              ?? (requesterId.isNotEmpty ? 'ID: ${requesterId.substring(0, 8)}…' : 'Unknown');
          final status = (r['status'] ?? 'open').toString();
          final statusColor = status == 'fulfilled'
              ? Colors.green : status == 'closed'
              ? Colors.grey : Colors.orange;
          return Container(
            margin: const EdgeInsets.only(bottom: 12),
            decoration: BoxDecoration(
              color: cardBg,
              borderRadius: BorderRadius.circular(14),
              boxShadow: dark ? [] : [BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 8, offset: const Offset(0, 2))],
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: CircleAvatar(
                backgroundColor: Colors.orange.withValues(alpha: 0.12),
                child: const Icon(Icons.back_hand, color: Colors.orange, size: 20),
              ),
              title: Text(r['medication_name'] ?? 'Unknown medication',
                  style: TextStyle(color: textPrimary, fontWeight: FontWeight.w600)),
              subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const SizedBox(height: 2),
                Text('By: $requesterName', style: TextStyle(color: textSecond, fontSize: 12)),
                if ((r['message'] ?? '').toString().isNotEmpty) ...[ const SizedBox(height: 2),
                  Text(r['message'].toString(), maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: TextStyle(color: textSecond, fontSize: 12))],
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(color: statusColor.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(20)),
                  child: Text(status.toUpperCase(), style: TextStyle(fontSize: 11, color: statusColor, fontWeight: FontWeight.w700)),
                ),
              ]),
              trailing: IconButton(
                icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                onPressed: () => _deleteRequest(r['id'].toString()),
              ),
            ),
          );
        },
      ),
    );
  }
}
